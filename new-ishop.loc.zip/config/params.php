<?php

return [
    'admin_email' => 'admin@i.ua',
    'site_name' => 'Name',
    'pagination' => 3
];