<?php

use wfm\Router;
Router::add('^admin/?$', ['controller'=>'Main', 'action'=>'index', 'admin_prefix'=>'admin']);
Router::add('^admin/(?P<controller>[a-z0-9-_]+)/?(?P<action>[a-z0-9-_]+)/?$', ['admin_prefix'=>'admin']);
Router::add('^$', ['controller'=>'Main', 'action'=>'index']);
Router::add('^(?P<controller>[a-z0-9-_]+)/(?P<action>[a-z0-9-_]+)/?$', ['controller'=>'Main', 'action'=>'index']);
